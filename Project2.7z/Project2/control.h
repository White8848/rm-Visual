#pragma once
class control
{
public:
	control(int a, int b, int c, int d);
	~control();
	void compare(int x[], int y, int z[], int r);
private:
	int x;
	int y;
	int z;
	int r;
};
